--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2 (Debian 13.2-1.pgdg100+1)
-- Dumped by pg_dump version 13.2 (Debian 13.2-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE tryt20;
--
-- Name: tryt20; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE tryt20 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


\connect tryt20

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ir_action_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_action_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ir_action; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_action (
    id integer DEFAULT nextval('public.ir_action_id_seq'::regclass) NOT NULL,
    active boolean DEFAULT false,
    create_date timestamp(6) without time zone,
    create_uid integer,
    icon integer,
    name character varying NOT NULL,
    type character varying NOT NULL,
    usage character varying,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_action_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_action; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_action IS 'Action';


--
-- Name: ir_action-res_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."ir_action-res_group_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_action-res_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ir_action-res_group" (
    id integer DEFAULT nextval('public."ir_action-res_group_id_seq"'::regclass) NOT NULL,
    action integer NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    "group" integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT "ir_action-res_group_id_positive" CHECK ((id >= 0))
);


--
-- Name: TABLE "ir_action-res_group"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."ir_action-res_group" IS 'Action - Group';


--
-- Name: ir_action_act_window_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_action_act_window_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_action_act_window; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_action_act_window (
    id integer DEFAULT nextval('public.ir_action_act_window_id_seq'::regclass) NOT NULL,
    action integer NOT NULL,
    context character varying,
    context_domain character varying,
    context_model character varying,
    create_date timestamp(6) without time zone,
    create_uid integer,
    domain character varying,
    "limit" integer,
    "order" character varying,
    res_model character varying,
    search_value character varying,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_action_act_window_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_action_act_window; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_action_act_window IS 'Action act window';


--
-- Name: ir_action_act_window_domain_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_action_act_window_domain_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_action_act_window_domain; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_action_act_window_domain (
    id integer DEFAULT nextval('public.ir_action_act_window_domain_id_seq'::regclass) NOT NULL,
    act_window integer NOT NULL,
    active boolean DEFAULT false,
    count boolean DEFAULT false,
    create_date timestamp(6) without time zone,
    create_uid integer,
    domain character varying,
    name character varying,
    sequence integer,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_action_act_window_domain_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_action_act_window_domain; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_action_act_window_domain IS 'Action act window domain';


--
-- Name: ir_action_act_window_view_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_action_act_window_view_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_action_act_window_view; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_action_act_window_view (
    id integer DEFAULT nextval('public.ir_action_act_window_view_id_seq'::regclass) NOT NULL,
    act_window integer,
    active boolean DEFAULT false,
    create_date timestamp(6) without time zone,
    create_uid integer,
    sequence integer,
    view integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_action_act_window_view_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_action_act_window_view; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_action_act_window_view IS 'Action act window view';


--
-- Name: ir_action_keyword_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_action_keyword_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_action_keyword; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_action_keyword (
    id integer DEFAULT nextval('public.ir_action_keyword_id_seq'::regclass) NOT NULL,
    action integer,
    create_date timestamp(6) without time zone,
    create_uid integer,
    keyword character varying NOT NULL,
    model character varying,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_action_keyword_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_action_keyword; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_action_keyword IS 'Action keyword';


--
-- Name: ir_action_report_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_action_report_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_action_report; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_action_report (
    id integer DEFAULT nextval('public.ir_action_report_id_seq'::regclass) NOT NULL,
    action integer NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    direct_print boolean DEFAULT false,
    extension character varying,
    model character varying,
    module character varying,
    report character varying,
    report_content_custom bytea,
    report_name character varying NOT NULL,
    single boolean DEFAULT false,
    template_extension character varying NOT NULL,
    translatable boolean DEFAULT false,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_action_report_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_action_report; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_action_report IS 'Action report';


--
-- Name: ir_action_url_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_action_url_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_action_url; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_action_url (
    id integer DEFAULT nextval('public.ir_action_url_id_seq'::regclass) NOT NULL,
    action integer NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    url character varying NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_action_url_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_action_url; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_action_url IS 'Action URL';


--
-- Name: ir_action_wizard_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_action_wizard_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_action_wizard; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_action_wizard (
    id integer DEFAULT nextval('public.ir_action_wizard_id_seq'::regclass) NOT NULL,
    action integer NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    model character varying,
    "window" boolean DEFAULT false,
    wiz_name character varying NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_action_wizard_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_action_wizard; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_action_wizard IS 'Action wizard';


--
-- Name: ir_attachment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_attachment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_attachment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_attachment (
    id integer DEFAULT nextval('public.ir_attachment_id_seq'::regclass) NOT NULL,
    copy_to_resources character varying,
    create_date timestamp(6) without time zone,
    create_uid integer,
    data bytea,
    description text,
    file_id character varying,
    link character varying,
    name character varying NOT NULL,
    resource character varying NOT NULL,
    type character varying NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_attachment_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_attachment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_attachment IS 'Attachment';


--
-- Name: ir_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_cache_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_cache (
    id integer DEFAULT nextval('public.ir_cache_id_seq'::regclass) NOT NULL,
    name character varying NOT NULL,
    "timestamp" timestamp without time zone,
    create_date timestamp(6) without time zone,
    create_uid integer,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_cache_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_cache; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_cache IS 'Cache';


--
-- Name: ir_calendar_day_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_calendar_day_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_calendar_day; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_calendar_day (
    id integer DEFAULT nextval('public.ir_calendar_day_id_seq'::regclass) NOT NULL,
    abbreviation character varying NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    index integer NOT NULL,
    name character varying NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer
);


--
-- Name: TABLE ir_calendar_day; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_calendar_day IS 'Day';


--
-- Name: ir_calendar_month_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_calendar_month_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_calendar_month; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_calendar_month (
    id integer DEFAULT nextval('public.ir_calendar_month_id_seq'::regclass) NOT NULL,
    abbreviation character varying NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    index integer NOT NULL,
    name character varying NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer
);


--
-- Name: TABLE ir_calendar_month; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_calendar_month IS 'Month';


--
-- Name: ir_configuration_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_configuration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_configuration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_configuration (
    id integer DEFAULT nextval('public.ir_configuration_id_seq'::regclass) NOT NULL,
    language character varying,
    hostname character varying,
    create_date timestamp(6) without time zone,
    create_uid integer,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_configuration_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_configuration; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_configuration IS 'Configuration';


--
-- Name: ir_cron_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_cron_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_cron; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_cron (
    id integer DEFAULT nextval('public.ir_cron_id_seq'::regclass) NOT NULL,
    active boolean DEFAULT false,
    create_date timestamp(6) without time zone,
    create_uid integer,
    day integer,
    hour integer,
    interval_number integer NOT NULL,
    interval_type character varying NOT NULL,
    method character varying NOT NULL,
    minute integer,
    next_call timestamp(0) without time zone,
    weekday integer,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_cron_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_cron; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_cron IS 'Cron';


--
-- Name: ir_email_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_email_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_email; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_email (
    id integer DEFAULT nextval('public.ir_email_id_seq'::regclass) NOT NULL,
    body character varying,
    create_date timestamp(6) without time zone,
    create_uid integer,
    recipients character varying,
    recipients_hidden character varying,
    recipients_secondary character varying,
    resource character varying NOT NULL,
    subject character varying,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_email_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_email IS 'Email';


--
-- Name: ir_email_address_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_email_address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_email_address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_email_address (
    id integer DEFAULT nextval('public.ir_email_address_id_seq'::regclass) NOT NULL,
    address character varying NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    email integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_email_address_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_email_address; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_email_address IS 'Email Address';


--
-- Name: ir_email_template_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_email_template_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_email_template; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_email_template (
    id integer DEFAULT nextval('public.ir_email_template_id_seq'::regclass) NOT NULL,
    body text,
    create_date timestamp(6) without time zone,
    create_uid integer,
    model integer NOT NULL,
    name character varying NOT NULL,
    recipients integer,
    recipients_hidden integer,
    recipients_hidden_pyson character varying,
    recipients_pyson character varying,
    recipients_secondary integer,
    recipients_secondary_pyson character varying,
    subject character varying,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_email_template_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_email_template; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_email_template IS 'Email Template';


--
-- Name: ir_email_template-ir_action_report_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."ir_email_template-ir_action_report_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_email_template-ir_action_report; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ir_email_template-ir_action_report" (
    id integer DEFAULT nextval('public."ir_email_template-ir_action_report_id_seq"'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    report integer NOT NULL,
    template integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT "ir_email_template-ir_action_report_id_positive" CHECK ((id >= 0))
);


--
-- Name: TABLE "ir_email_template-ir_action_report"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."ir_email_template-ir_action_report" IS 'Email Template - Report';


--
-- Name: ir_export_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_export_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_export; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_export (
    id integer DEFAULT nextval('public.ir_export_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    name character varying,
    resource character varying,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_export_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_export; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_export IS 'Export';


--
-- Name: ir_export-res_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."ir_export-res_group_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_export-res_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ir_export-res_group" (
    id integer DEFAULT nextval('public."ir_export-res_group_id_seq"'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    export integer NOT NULL,
    "group" integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT "ir_export-res_group_id_positive" CHECK ((id >= 0))
);


--
-- Name: TABLE "ir_export-res_group"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."ir_export-res_group" IS 'Export Group';


--
-- Name: ir_export-write-res_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."ir_export-write-res_group_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_export-write-res_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ir_export-write-res_group" (
    id integer DEFAULT nextval('public."ir_export-write-res_group_id_seq"'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    export integer NOT NULL,
    "group" integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT "ir_export-write-res_group_id_positive" CHECK ((id >= 0))
);


--
-- Name: TABLE "ir_export-write-res_group"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."ir_export-write-res_group" IS 'Export Modification Group';


--
-- Name: ir_export_line_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_export_line_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_export_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_export_line (
    id integer DEFAULT nextval('public.ir_export_line_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    export integer NOT NULL,
    name character varying,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_export_line_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_export_line; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_export_line IS 'Export line';


--
-- Name: ir_lang_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_lang_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_lang; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_lang (
    id integer DEFAULT nextval('public.ir_lang_id_seq'::regclass) NOT NULL,
    name character varying NOT NULL,
    code character varying NOT NULL,
    translatable boolean DEFAULT false,
    parent character varying,
    active boolean DEFAULT false,
    direction character varying NOT NULL,
    am character varying,
    create_date timestamp(6) without time zone,
    create_uid integer,
    date character varying NOT NULL,
    decimal_point character varying NOT NULL,
    "grouping" character varying NOT NULL,
    mon_decimal_point character varying NOT NULL,
    mon_grouping character varying NOT NULL,
    mon_thousands_sep character varying,
    n_cs_precedes boolean DEFAULT false,
    n_sep_by_space boolean DEFAULT false,
    n_sign_posn integer NOT NULL,
    negative_sign character varying,
    p_cs_precedes boolean DEFAULT false,
    p_sep_by_space boolean DEFAULT false,
    p_sign_posn integer NOT NULL,
    pm character varying,
    positive_sign character varying,
    thousands_sep character varying,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_lang_check_decimal_point_thousands_sep CHECK (((decimal_point)::text <> (thousands_sep)::text)),
    CONSTRAINT ir_lang_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_lang; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_lang IS 'Language';


--
-- Name: ir_message_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_message (
    id integer DEFAULT nextval('public.ir_message_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    text text NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_message_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_message; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_message IS 'Message';


--
-- Name: ir_model_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_model_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_model (
    id integer DEFAULT nextval('public.ir_model_id_seq'::regclass) NOT NULL,
    model character varying NOT NULL,
    name character varying,
    info text,
    module character varying,
    create_date timestamp(6) without time zone,
    create_uid integer,
    global_search_p boolean DEFAULT false,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_model_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_model; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_model IS 'Model';


--
-- Name: ir_model_access_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_model_access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_model_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_model_access (
    id integer DEFAULT nextval('public.ir_model_access_id_seq'::regclass) NOT NULL,
    active boolean DEFAULT false,
    create_date timestamp(6) without time zone,
    create_uid integer,
    description text,
    "group" integer,
    model integer NOT NULL,
    perm_create boolean DEFAULT false,
    perm_delete boolean DEFAULT false,
    perm_read boolean DEFAULT false,
    perm_write boolean DEFAULT false,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_model_access_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_model_access; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_model_access IS 'Model access';


--
-- Name: ir_model_button_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_model_button_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_model_button; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_model_button (
    id integer DEFAULT nextval('public.ir_model_button_id_seq'::regclass) NOT NULL,
    confirm text,
    create_date timestamp(6) without time zone,
    create_uid integer,
    help text,
    model integer NOT NULL,
    name character varying NOT NULL,
    string character varying,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_model_button_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_model_button; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_model_button IS 'Model Button';


--
-- Name: ir_model_button-button_reset_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."ir_model_button-button_reset_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_model_button-button_reset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ir_model_button-button_reset" (
    id integer DEFAULT nextval('public."ir_model_button-button_reset_id_seq"'::regclass) NOT NULL,
    button integer NOT NULL,
    button_ruled integer NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT "ir_model_button-button_reset_id_positive" CHECK ((id >= 0))
);


--
-- Name: TABLE "ir_model_button-button_reset"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."ir_model_button-button_reset" IS 'Model Button Reset';


--
-- Name: ir_model_button-res_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."ir_model_button-res_group_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_model_button-res_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ir_model_button-res_group" (
    id integer DEFAULT nextval('public."ir_model_button-res_group_id_seq"'::regclass) NOT NULL,
    active boolean DEFAULT false,
    button integer NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    "group" integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT "ir_model_button-res_group_id_positive" CHECK ((id >= 0))
);


--
-- Name: TABLE "ir_model_button-res_group"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."ir_model_button-res_group" IS 'Model Button - Group';


--
-- Name: ir_model_button_click_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_model_button_click_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_model_button_click; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_model_button_click (
    id integer DEFAULT nextval('public.ir_model_button_click_id_seq'::regclass) NOT NULL,
    active boolean DEFAULT false,
    button integer NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    record_id integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    "user" integer,
    CONSTRAINT ir_model_button_click_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_model_button_click; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_model_button_click IS 'Model Button Click';


--
-- Name: ir_model_button_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_model_button_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_model_button_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_model_button_rule (
    id integer DEFAULT nextval('public.ir_model_button_rule_id_seq'::regclass) NOT NULL,
    button integer NOT NULL,
    condition character varying,
    create_date timestamp(6) without time zone,
    create_uid integer,
    description character varying,
    number_user integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    "group" integer,
    CONSTRAINT ir_model_button_rule_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_model_button_rule; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_model_button_rule IS 'Model Button Rule';


--
-- Name: ir_model_data_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_model_data_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_model_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_model_data (
    id integer DEFAULT nextval('public.ir_model_data_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    db_id integer,
    fs_id character varying NOT NULL,
    fs_values text,
    model character varying NOT NULL,
    module character varying NOT NULL,
    noupdate boolean DEFAULT false,
    "values" text,
    write_date timestamp(6) without time zone,
    write_uid integer
);


--
-- Name: TABLE ir_model_data; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_model_data IS 'Model data';


--
-- Name: ir_model_field_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_model_field_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_model_field; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_model_field (
    id integer DEFAULT nextval('public.ir_model_field_id_seq'::regclass) NOT NULL,
    model integer NOT NULL,
    name character varying NOT NULL,
    relation character varying,
    field_description character varying,
    ttype character varying,
    help text,
    module character varying,
    create_date timestamp(6) without time zone,
    create_uid integer,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_model_field_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_model_field; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_model_field IS 'Model field';


--
-- Name: ir_model_field_access_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_model_field_access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_model_field_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_model_field_access (
    id integer DEFAULT nextval('public.ir_model_field_access_id_seq'::regclass) NOT NULL,
    active boolean DEFAULT false,
    create_date timestamp(6) without time zone,
    create_uid integer,
    description text,
    field integer NOT NULL,
    "group" integer,
    perm_create boolean DEFAULT false,
    perm_delete boolean DEFAULT false,
    perm_read boolean DEFAULT false,
    perm_write boolean DEFAULT false,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_model_field_access_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_model_field_access; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_model_field_access IS 'Model Field Access';


--
-- Name: ir_module_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_module_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_module; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_module (
    id integer DEFAULT nextval('public.ir_module_id_seq'::regclass) NOT NULL,
    create_uid integer,
    create_date timestamp without time zone,
    write_date timestamp without time zone,
    write_uid integer,
    name character varying NOT NULL,
    state character varying
);


--
-- Name: TABLE ir_module; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_module IS 'Module';


--
-- Name: ir_module_config_wizard_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_module_config_wizard_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_module_config_wizard_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_module_config_wizard_item (
    id integer DEFAULT nextval('public.ir_module_config_wizard_item_id_seq'::regclass) NOT NULL,
    action integer NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    sequence integer,
    state character varying NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_module_config_wizard_item_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_module_config_wizard_item; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_module_config_wizard_item IS 'Config wizard to run after activating a module';


--
-- Name: ir_module_dependency_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_module_dependency_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_module_dependency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_module_dependency (
    id integer DEFAULT nextval('public.ir_module_dependency_id_seq'::regclass) NOT NULL,
    create_uid integer,
    create_date timestamp without time zone,
    write_date timestamp without time zone,
    write_uid integer,
    name character varying,
    module integer NOT NULL,
    CONSTRAINT ir_module_dependency_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_module_dependency; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_module_dependency IS 'Module dependency';


--
-- Name: ir_note_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_note_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_note (
    id integer DEFAULT nextval('public.ir_note_id_seq'::regclass) NOT NULL,
    copy_to_resources character varying,
    create_date timestamp(6) without time zone,
    create_uid integer,
    message text,
    resource character varying NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_note_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_note IS 'Note';


--
-- Name: ir_note_read_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_note_read_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_note_read; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_note_read (
    id integer DEFAULT nextval('public.ir_note_read_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    note integer NOT NULL,
    "user" integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_note_read_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_note_read; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_note_read IS 'Note Read';


--
-- Name: ir_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_queue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_queue (
    id integer DEFAULT nextval('public.ir_queue_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    data text,
    dequeued_at timestamp(6) without time zone,
    enqueued_at timestamp(6) without time zone NOT NULL,
    expected_at timestamp(6) without time zone,
    finished_at timestamp(6) without time zone,
    name character varying NOT NULL,
    scheduled_at timestamp(6) without time zone,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_queue_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_queue; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_queue IS 'Queue';


--
-- Name: ir_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_rule (
    id integer DEFAULT nextval('public.ir_rule_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    domain character varying NOT NULL,
    rule_group integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_rule_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_rule; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_rule IS 'Rule';


--
-- Name: ir_rule_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_rule_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_rule_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_rule_group (
    id integer DEFAULT nextval('public.ir_rule_group_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    default_p boolean DEFAULT false,
    global_p boolean DEFAULT false,
    model integer NOT NULL,
    name character varying NOT NULL,
    perm_create boolean DEFAULT false,
    perm_delete boolean DEFAULT false,
    perm_read boolean DEFAULT false,
    perm_write boolean DEFAULT false,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_rule_group_global_default_exclusive CHECK (((global_p = false) OR (default_p = false))),
    CONSTRAINT ir_rule_group_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_rule_group; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_rule_group IS 'Rule group';


--
-- Name: ir_rule_group-res_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."ir_rule_group-res_group_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_rule_group-res_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ir_rule_group-res_group" (
    id integer DEFAULT nextval('public."ir_rule_group-res_group_id_seq"'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    "group" integer NOT NULL,
    rule_group integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT "ir_rule_group-res_group_id_positive" CHECK ((id >= 0))
);


--
-- Name: TABLE "ir_rule_group-res_group"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."ir_rule_group-res_group" IS 'Rule Group - Group';


--
-- Name: ir_sequence_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_sequence_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_sequence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_sequence (
    id integer DEFAULT nextval('public.ir_sequence_id_seq'::regclass) NOT NULL,
    active boolean DEFAULT false,
    code character varying NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    last_timestamp integer,
    name character varying NOT NULL,
    number_increment integer,
    number_next_internal integer,
    padding integer,
    prefix character varying,
    suffix character varying,
    timestamp_offset double precision NOT NULL,
    timestamp_rounding double precision NOT NULL,
    type character varying,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_sequence_check_timestamp_rounding CHECK ((timestamp_rounding > (0)::double precision)),
    CONSTRAINT ir_sequence_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_sequence; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_sequence IS 'Sequence';


--
-- Name: ir_sequence_strict_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_sequence_strict_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_sequence_strict; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_sequence_strict (
    id integer DEFAULT nextval('public.ir_sequence_strict_id_seq'::regclass) NOT NULL,
    active boolean DEFAULT false,
    code character varying NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    last_timestamp integer,
    name character varying NOT NULL,
    number_increment integer,
    number_next_internal integer,
    padding integer,
    prefix character varying,
    suffix character varying,
    timestamp_offset double precision NOT NULL,
    timestamp_rounding double precision NOT NULL,
    type character varying,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_sequence_strict_check_timestamp_rounding CHECK ((timestamp_rounding > (0)::double precision)),
    CONSTRAINT ir_sequence_strict_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_sequence_strict; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_sequence_strict IS 'Sequence Strict';


--
-- Name: ir_sequence_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_sequence_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_sequence_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_sequence_type (
    id integer DEFAULT nextval('public.ir_sequence_type_id_seq'::regclass) NOT NULL,
    code character varying NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    name character varying NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_sequence_type_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_sequence_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_sequence_type IS 'Sequence type';


--
-- Name: ir_sequence_type-res_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."ir_sequence_type-res_group_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_sequence_type-res_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ir_sequence_type-res_group" (
    id integer DEFAULT nextval('public."ir_sequence_type-res_group_id_seq"'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    "group" integer NOT NULL,
    sequence_type integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT "ir_sequence_type-res_group_id_positive" CHECK ((id >= 0))
);


--
-- Name: TABLE "ir_sequence_type-res_group"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."ir_sequence_type-res_group" IS 'Sequence Type - Group';


--
-- Name: ir_session_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_session_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_session (
    id integer DEFAULT nextval('public.ir_session_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    key character varying NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_session_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_session; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_session IS 'Session';


--
-- Name: ir_session_wizard_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_session_wizard_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_session_wizard; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_session_wizard (
    id integer DEFAULT nextval('public.ir_session_wizard_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    data text,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_session_wizard_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_session_wizard; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_session_wizard IS 'Session Wizard';


--
-- Name: ir_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_translation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_translation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_translation (
    id integer DEFAULT nextval('public.ir_translation_id_seq'::regclass) NOT NULL,
    lang character varying,
    src text,
    name character varying NOT NULL,
    res_id integer NOT NULL,
    value text,
    type character varying NOT NULL,
    module character varying,
    fuzzy boolean DEFAULT false,
    create_date timestamp(6) without time zone,
    create_uid integer,
    overriding_module character varying,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_translation_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_translation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_translation IS 'Translation';


--
-- Name: ir_trigger_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_trigger_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_trigger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_trigger (
    id integer DEFAULT nextval('public.ir_trigger_id_seq'::regclass) NOT NULL,
    action character varying NOT NULL,
    active boolean DEFAULT false,
    condition character varying NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    limit_number integer NOT NULL,
    minimum_time_delay interval,
    model integer NOT NULL,
    name character varying NOT NULL,
    on_create boolean DEFAULT false,
    on_delete boolean DEFAULT false,
    on_time boolean DEFAULT false,
    on_write boolean DEFAULT false,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_trigger_id_positive CHECK ((id >= 0)),
    CONSTRAINT ir_trigger_on_exclusive CHECK ((NOT ((on_time = true) AND ((on_create = true) OR (on_write = true) OR (on_delete = true)))))
);


--
-- Name: TABLE ir_trigger; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_trigger IS 'Trigger';


--
-- Name: ir_trigger__history___id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_trigger__history___id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_trigger__history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_trigger__history (
    id integer,
    __id integer DEFAULT nextval('public.ir_trigger__history___id_seq'::regclass) NOT NULL
);


--
-- Name: TABLE ir_trigger__history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_trigger__history IS 'Trigger';


--
-- Name: ir_trigger_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_trigger_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_trigger_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_trigger_log (
    id integer DEFAULT nextval('public.ir_trigger_log_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    record_id integer NOT NULL,
    trigger integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_trigger_log_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_trigger_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_trigger_log IS 'Trigger Log';


--
-- Name: ir_ui_icon_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_ui_icon_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_ui_icon; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_ui_icon (
    id integer DEFAULT nextval('public.ir_ui_icon_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    module character varying NOT NULL,
    name character varying NOT NULL,
    path character varying NOT NULL,
    sequence integer,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_ui_icon_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_ui_icon; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_ui_icon IS 'Icon';


--
-- Name: ir_ui_menu_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_ui_menu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_ui_menu; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_ui_menu (
    id integer DEFAULT nextval('public.ir_ui_menu_id_seq'::regclass) NOT NULL,
    parent integer,
    name character varying NOT NULL,
    icon character varying,
    active boolean DEFAULT false,
    create_date timestamp(6) without time zone,
    create_uid integer,
    sequence integer,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_ui_menu_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_ui_menu; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_ui_menu IS 'UI menu';


--
-- Name: ir_ui_menu-res_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."ir_ui_menu-res_group_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_ui_menu-res_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ir_ui_menu-res_group" (
    id integer DEFAULT nextval('public."ir_ui_menu-res_group_id_seq"'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    "group" integer NOT NULL,
    menu integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT "ir_ui_menu-res_group_id_positive" CHECK ((id >= 0))
);


--
-- Name: TABLE "ir_ui_menu-res_group"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."ir_ui_menu-res_group" IS 'UI Menu - Group';


--
-- Name: ir_ui_menu_favorite_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_ui_menu_favorite_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_ui_menu_favorite; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_ui_menu_favorite (
    id integer DEFAULT nextval('public.ir_ui_menu_favorite_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    menu integer NOT NULL,
    sequence integer,
    "user" integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_ui_menu_favorite_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_ui_menu_favorite; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_ui_menu_favorite IS 'Menu Favorite';


--
-- Name: ir_ui_view_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_ui_view_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_ui_view; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_ui_view (
    id integer DEFAULT nextval('public.ir_ui_view_id_seq'::regclass) NOT NULL,
    model character varying,
    type character varying,
    data text,
    field_childs character varying,
    priority integer NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    domain character varying,
    inherit integer,
    module character varying,
    name character varying,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_ui_view_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_ui_view; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_ui_view IS 'View';


--
-- Name: ir_ui_view_search_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_ui_view_search_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_ui_view_search; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_ui_view_search (
    id integer DEFAULT nextval('public.ir_ui_view_search_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    domain character varying,
    model character varying NOT NULL,
    name character varying NOT NULL,
    "user" integer,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_ui_view_search_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_ui_view_search; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_ui_view_search IS 'View Search';


--
-- Name: ir_ui_view_tree_state_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_ui_view_tree_state_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_ui_view_tree_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_ui_view_tree_state (
    id integer DEFAULT nextval('public.ir_ui_view_tree_state_id_seq'::regclass) NOT NULL,
    child_name character varying,
    create_date timestamp(6) without time zone,
    create_uid integer,
    domain character varying NOT NULL,
    model character varying NOT NULL,
    nodes text,
    selected_nodes text,
    "user" integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_ui_view_tree_state_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_ui_view_tree_state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_ui_view_tree_state IS 'View Tree State';


--
-- Name: ir_ui_view_tree_width_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir_ui_view_tree_width_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir_ui_view_tree_width; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir_ui_view_tree_width (
    id integer DEFAULT nextval('public.ir_ui_view_tree_width_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    field character varying NOT NULL,
    model character varying NOT NULL,
    "user" integer NOT NULL,
    width integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT ir_ui_view_tree_width_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE ir_ui_view_tree_width; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ir_ui_view_tree_width IS 'View Tree Width';


--
-- Name: res_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.res_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: res_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.res_group (
    id integer DEFAULT nextval('public.res_group_id_seq'::regclass) NOT NULL,
    name character varying NOT NULL,
    active boolean DEFAULT false,
    create_date timestamp(6) without time zone,
    create_uid integer,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT res_group_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE res_group; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.res_group IS 'Group';


--
-- Name: res_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.res_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: res_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.res_user (
    id integer DEFAULT nextval('public.res_user_id_seq'::regclass) NOT NULL,
    name character varying,
    active boolean DEFAULT false,
    login character varying NOT NULL,
    password character varying,
    create_date timestamp(6) without time zone,
    create_uid integer,
    email character varying,
    language integer,
    menu integer NOT NULL,
    password_hash character varying,
    password_reset character varying,
    password_reset_expire timestamp(6) without time zone,
    signature text,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT res_user_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE res_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.res_user IS 'User';


--
-- Name: res_user-ir_action_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."res_user-ir_action_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: res_user-ir_action; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."res_user-ir_action" (
    id integer DEFAULT nextval('public."res_user-ir_action_id_seq"'::regclass) NOT NULL,
    action integer NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    "user" integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT "res_user-ir_action_id_positive" CHECK ((id >= 0))
);


--
-- Name: TABLE "res_user-ir_action"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."res_user-ir_action" IS 'User - Action';


--
-- Name: res_user-res_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."res_user-res_group_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: res_user-res_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."res_user-res_group" (
    id integer DEFAULT nextval('public."res_user-res_group_id_seq"'::regclass) NOT NULL,
    "user" integer NOT NULL,
    "group" integer NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT "res_user-res_group_id_positive" CHECK ((id >= 0))
);


--
-- Name: TABLE "res_user-res_group"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."res_user-res_group" IS 'User - Group';


--
-- Name: res_user_application_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.res_user_application_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: res_user_application; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.res_user_application (
    id integer DEFAULT nextval('public.res_user_application_id_seq'::regclass) NOT NULL,
    application character varying,
    create_date timestamp(6) without time zone,
    create_uid integer,
    key character varying NOT NULL,
    state character varying,
    "user" integer,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT res_user_application_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE res_user_application; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.res_user_application IS 'User Application';


--
-- Name: res_user_login_attempt_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.res_user_login_attempt_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: res_user_login_attempt; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.res_user_login_attempt (
    id integer DEFAULT nextval('public.res_user_login_attempt_id_seq'::regclass) NOT NULL,
    create_date timestamp(6) without time zone,
    create_uid integer,
    ip_address character varying,
    ip_network character varying,
    login character varying(512),
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT res_user_login_attempt_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE res_user_login_attempt; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.res_user_login_attempt IS 'Login Attempt

    This class is separated from the res.user one in order to prevent locking
    the res.user table when in a long running process.
    ';


--
-- Name: res_user_warning_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.res_user_warning_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: res_user_warning; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.res_user_warning (
    id integer DEFAULT nextval('public.res_user_warning_id_seq'::regclass) NOT NULL,
    always boolean DEFAULT false,
    create_date timestamp(6) without time zone,
    create_uid integer,
    name character varying NOT NULL,
    "user" integer NOT NULL,
    write_date timestamp(6) without time zone,
    write_uid integer,
    CONSTRAINT res_user_warning_id_positive CHECK ((id >= 0))
);


--
-- Name: TABLE res_user_warning; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.res_user_warning IS 'User Warning';


--
-- Data for Name: ir_action; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_action (id, active, create_date, create_uid, icon, name, type, usage, write_date, write_uid) FROM stdin;
\.
COPY public.ir_action (id, active, create_date, create_uid, icon, name, type, usage, write_date, write_uid) FROM '$$PATH$$/3913.dat';

--
-- Data for Name: ir_action-res_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ir_action-res_group" (id, action, create_date, create_uid, "group", write_date, write_uid) FROM stdin;
\.
COPY public."ir_action-res_group" (id, action, create_date, create_uid, "group", write_date, write_uid) FROM '$$PATH$$/3997.dat';

--
-- Data for Name: ir_action_act_window; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_action_act_window (id, action, context, context_domain, context_model, create_date, create_uid, domain, "limit", "order", res_model, search_value, write_date, write_uid) FROM stdin;
\.
COPY public.ir_action_act_window (id, action, context, context_domain, context_model, create_date, create_uid, domain, "limit", "order", res_model, search_value, write_date, write_uid) FROM '$$PATH$$/3919.dat';

--
-- Data for Name: ir_action_act_window_domain; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_action_act_window_domain (id, act_window, active, count, create_date, create_uid, domain, name, sequence, write_date, write_uid) FROM stdin;
\.
COPY public.ir_action_act_window_domain (id, act_window, active, count, create_date, create_uid, domain, name, sequence, write_date, write_uid) FROM '$$PATH$$/3923.dat';

--
-- Data for Name: ir_action_act_window_view; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_action_act_window_view (id, act_window, active, create_date, create_uid, sequence, view, write_date, write_uid) FROM stdin;
\.
COPY public.ir_action_act_window_view (id, act_window, active, create_date, create_uid, sequence, view, write_date, write_uid) FROM '$$PATH$$/3921.dat';

--
-- Data for Name: ir_action_keyword; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_action_keyword (id, action, create_date, create_uid, keyword, model, write_date, write_uid) FROM stdin;
\.
COPY public.ir_action_keyword (id, action, create_date, create_uid, keyword, model, write_date, write_uid) FROM '$$PATH$$/3915.dat';

--
-- Data for Name: ir_action_report; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_action_report (id, action, create_date, create_uid, direct_print, extension, model, module, report, report_content_custom, report_name, single, template_extension, translatable, write_date, write_uid) FROM stdin;
\.
COPY public.ir_action_report (id, action, create_date, create_uid, direct_print, extension, model, module, report, report_content_custom, report_name, single, template_extension, translatable, write_date, write_uid) FROM '$$PATH$$/3917.dat';

--
-- Data for Name: ir_action_url; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_action_url (id, action, create_date, create_uid, url, write_date, write_uid) FROM stdin;
\.
COPY public.ir_action_url (id, action, create_date, create_uid, url, write_date, write_uid) FROM '$$PATH$$/3927.dat';

--
-- Data for Name: ir_action_wizard; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_action_wizard (id, action, create_date, create_uid, model, "window", wiz_name, write_date, write_uid) FROM stdin;
\.
COPY public.ir_action_wizard (id, action, create_date, create_uid, model, "window", wiz_name, write_date, write_uid) FROM '$$PATH$$/3925.dat';

--
-- Data for Name: ir_attachment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_attachment (id, copy_to_resources, create_date, create_uid, data, description, file_id, link, name, resource, type, write_date, write_uid) FROM stdin;
\.
COPY public.ir_attachment (id, copy_to_resources, create_date, create_uid, data, description, file_id, link, name, resource, type, write_date, write_uid) FROM '$$PATH$$/3943.dat';

--
-- Data for Name: ir_cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_cache (id, name, "timestamp", create_date, create_uid, write_date, write_uid) FROM stdin;
\.
COPY public.ir_cache (id, name, "timestamp", create_date, create_uid, write_date, write_uid) FROM '$$PATH$$/3895.dat';

--
-- Data for Name: ir_calendar_day; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_calendar_day (id, abbreviation, create_date, create_uid, index, name, write_date, write_uid) FROM stdin;
\.
COPY public.ir_calendar_day (id, abbreviation, create_date, create_uid, index, name, write_date, write_uid) FROM '$$PATH$$/3951.dat';

--
-- Data for Name: ir_calendar_month; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_calendar_month (id, abbreviation, create_date, create_uid, index, name, write_date, write_uid) FROM stdin;
\.
COPY public.ir_calendar_month (id, abbreviation, create_date, create_uid, index, name, write_date, write_uid) FROM '$$PATH$$/3975.dat';

--
-- Data for Name: ir_configuration; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_configuration (id, language, hostname, create_date, create_uid, write_date, write_uid) FROM stdin;
\.
COPY public.ir_configuration (id, language, hostname, create_date, create_uid, write_date, write_uid) FROM '$$PATH$$/3871.dat';

--
-- Data for Name: ir_cron; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_cron (id, active, create_date, create_uid, day, hour, interval_number, interval_type, method, minute, next_call, weekday, write_date, write_uid) FROM stdin;
\.
COPY public.ir_cron (id, active, create_date, create_uid, day, hour, interval_number, interval_type, method, minute, next_call, weekday, write_date, write_uid) FROM '$$PATH$$/3949.dat';

--
-- Data for Name: ir_email; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_email (id, body, create_date, create_uid, recipients, recipients_hidden, recipients_secondary, resource, subject, write_date, write_uid) FROM stdin;
\.
COPY public.ir_email (id, body, create_date, create_uid, recipients, recipients_hidden, recipients_secondary, resource, subject, write_date, write_uid) FROM '$$PATH$$/3979.dat';

--
-- Data for Name: ir_email_address; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_email_address (id, address, create_date, create_uid, email, write_date, write_uid) FROM stdin;
\.
COPY public.ir_email_address (id, address, create_date, create_uid, email, write_date, write_uid) FROM '$$PATH$$/3981.dat';

--
-- Data for Name: ir_email_template; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_email_template (id, body, create_date, create_uid, model, name, recipients, recipients_hidden, recipients_hidden_pyson, recipients_pyson, recipients_secondary, recipients_secondary_pyson, subject, write_date, write_uid) FROM stdin;
\.
COPY public.ir_email_template (id, body, create_date, create_uid, model, name, recipients, recipients_hidden, recipients_hidden_pyson, recipients_pyson, recipients_secondary, recipients_secondary_pyson, subject, write_date, write_uid) FROM '$$PATH$$/3983.dat';

--
-- Data for Name: ir_email_template-ir_action_report; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ir_email_template-ir_action_report" (id, create_date, create_uid, report, template, write_date, write_uid) FROM stdin;
\.
COPY public."ir_email_template-ir_action_report" (id, create_date, create_uid, report, template, write_date, write_uid) FROM '$$PATH$$/3985.dat';

--
-- Data for Name: ir_export; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_export (id, create_date, create_uid, name, resource, write_date, write_uid) FROM stdin;
\.
COPY public.ir_export (id, create_date, create_uid, name, resource, write_date, write_uid) FROM '$$PATH$$/3953.dat';

--
-- Data for Name: ir_export-res_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ir_export-res_group" (id, create_date, create_uid, export, "group", write_date, write_uid) FROM stdin;
\.
COPY public."ir_export-res_group" (id, create_date, create_uid, export, "group", write_date, write_uid) FROM '$$PATH$$/4005.dat';

--
-- Data for Name: ir_export-write-res_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ir_export-write-res_group" (id, create_date, create_uid, export, "group", write_date, write_uid) FROM stdin;
\.
COPY public."ir_export-write-res_group" (id, create_date, create_uid, export, "group", write_date, write_uid) FROM '$$PATH$$/4007.dat';

--
-- Data for Name: ir_export_line; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_export_line (id, create_date, create_uid, export, name, write_date, write_uid) FROM stdin;
\.
COPY public.ir_export_line (id, create_date, create_uid, export, name, write_date, write_uid) FROM '$$PATH$$/3955.dat';

--
-- Data for Name: ir_lang; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_lang (id, name, code, translatable, parent, active, direction, am, create_date, create_uid, date, decimal_point, "grouping", mon_decimal_point, mon_grouping, mon_thousands_sep, n_cs_precedes, n_sep_by_space, n_sign_posn, negative_sign, p_cs_precedes, p_sep_by_space, p_sign_posn, pm, positive_sign, thousands_sep, write_date, write_uid) FROM stdin;
\.
COPY public.ir_lang (id, name, code, translatable, parent, active, direction, am, create_date, create_uid, date, decimal_point, "grouping", mon_decimal_point, mon_grouping, mon_thousands_sep, n_cs_precedes, n_sep_by_space, n_sign_posn, negative_sign, p_cs_precedes, p_sep_by_space, p_sign_posn, pm, positive_sign, thousands_sep, write_date, write_uid) FROM '$$PATH$$/3883.dat';

--
-- Data for Name: ir_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_message (id, create_date, create_uid, text, write_date, write_uid) FROM stdin;
\.
COPY public.ir_message (id, create_date, create_uid, text, write_date, write_uid) FROM '$$PATH$$/3977.dat';

--
-- Data for Name: ir_model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_model (id, model, name, info, module, create_date, create_uid, global_search_p, write_date, write_uid) FROM stdin;
\.
COPY public.ir_model (id, model, name, info, module, create_date, create_uid, global_search_p, write_date, write_uid) FROM '$$PATH$$/3873.dat';

--
-- Data for Name: ir_model_access; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_model_access (id, active, create_date, create_uid, description, "group", model, perm_create, perm_delete, perm_read, perm_write, write_date, write_uid) FROM stdin;
\.
COPY public.ir_model_access (id, active, create_date, create_uid, description, "group", model, perm_create, perm_delete, perm_read, perm_write, write_date, write_uid) FROM '$$PATH$$/3929.dat';

--
-- Data for Name: ir_model_button; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_model_button (id, confirm, create_date, create_uid, help, model, name, string, write_date, write_uid) FROM stdin;
\.
COPY public.ir_model_button (id, confirm, create_date, create_uid, help, model, name, string, write_date, write_uid) FROM '$$PATH$$/3933.dat';

--
-- Data for Name: ir_model_button-button_reset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ir_model_button-button_reset" (id, button, button_ruled, create_date, create_uid, write_date, write_uid) FROM stdin;
\.
COPY public."ir_model_button-button_reset" (id, button, button_ruled, create_date, create_uid, write_date, write_uid) FROM '$$PATH$$/3939.dat';

--
-- Data for Name: ir_model_button-res_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ir_model_button-res_group" (id, active, button, create_date, create_uid, "group", write_date, write_uid) FROM stdin;
\.
COPY public."ir_model_button-res_group" (id, active, button, create_date, create_uid, "group", write_date, write_uid) FROM '$$PATH$$/3999.dat';

--
-- Data for Name: ir_model_button_click; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_model_button_click (id, active, button, create_date, create_uid, record_id, write_date, write_uid, "user") FROM stdin;
\.
COPY public.ir_model_button_click (id, active, button, create_date, create_uid, record_id, write_date, write_uid, "user") FROM '$$PATH$$/3937.dat';

--
-- Data for Name: ir_model_button_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_model_button_rule (id, button, condition, create_date, create_uid, description, number_user, write_date, write_uid, "group") FROM stdin;
\.
COPY public.ir_model_button_rule (id, button, condition, create_date, create_uid, description, number_user, write_date, write_uid, "group") FROM '$$PATH$$/3935.dat';

--
-- Data for Name: ir_model_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_model_data (id, create_date, create_uid, db_id, fs_id, fs_values, model, module, noupdate, "values", write_date, write_uid) FROM stdin;
\.
COPY public.ir_model_data (id, create_date, create_uid, db_id, fs_id, fs_values, model, module, noupdate, "values", write_date, write_uid) FROM '$$PATH$$/3941.dat';

--
-- Data for Name: ir_model_field; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_model_field (id, model, name, relation, field_description, ttype, help, module, create_date, create_uid, write_date, write_uid) FROM stdin;
\.
COPY public.ir_model_field (id, model, name, relation, field_description, ttype, help, module, create_date, create_uid, write_date, write_uid) FROM '$$PATH$$/3875.dat';

--
-- Data for Name: ir_model_field_access; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_model_field_access (id, active, create_date, create_uid, description, field, "group", perm_create, perm_delete, perm_read, perm_write, write_date, write_uid) FROM stdin;
\.
COPY public.ir_model_field_access (id, active, create_date, create_uid, description, field, "group", perm_create, perm_delete, perm_read, perm_write, write_date, write_uid) FROM '$$PATH$$/3931.dat';

--
-- Data for Name: ir_module; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_module (id, create_uid, create_date, write_date, write_uid, name, state) FROM stdin;
\.
COPY public.ir_module (id, create_uid, create_date, write_date, write_uid, name, state) FROM '$$PATH$$/3891.dat';

--
-- Data for Name: ir_module_config_wizard_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_module_config_wizard_item (id, action, create_date, create_uid, sequence, state, write_date, write_uid) FROM stdin;
\.
COPY public.ir_module_config_wizard_item (id, action, create_date, create_uid, sequence, state, write_date, write_uid) FROM '$$PATH$$/3961.dat';

--
-- Data for Name: ir_module_dependency; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_module_dependency (id, create_uid, create_date, write_date, write_uid, name, module) FROM stdin;
\.
COPY public.ir_module_dependency (id, create_uid, create_date, write_date, write_uid, name, module) FROM '$$PATH$$/3893.dat';

--
-- Data for Name: ir_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_note (id, copy_to_resources, create_date, create_uid, message, resource, write_date, write_uid) FROM stdin;
\.
COPY public.ir_note (id, copy_to_resources, create_date, create_uid, message, resource, write_date, write_uid) FROM '$$PATH$$/3945.dat';

--
-- Data for Name: ir_note_read; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_note_read (id, create_date, create_uid, note, "user", write_date, write_uid) FROM stdin;
\.
COPY public.ir_note_read (id, create_date, create_uid, note, "user", write_date, write_uid) FROM '$$PATH$$/3947.dat';

--
-- Data for Name: ir_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_queue (id, create_date, create_uid, data, dequeued_at, enqueued_at, expected_at, finished_at, name, scheduled_at, write_date, write_uid) FROM stdin;
\.
COPY public.ir_queue (id, create_date, create_uid, data, dequeued_at, enqueued_at, expected_at, finished_at, name, scheduled_at, write_date, write_uid) FROM '$$PATH$$/3973.dat';

--
-- Data for Name: ir_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_rule (id, create_date, create_uid, domain, rule_group, write_date, write_uid) FROM stdin;
\.
COPY public.ir_rule (id, create_date, create_uid, domain, rule_group, write_date, write_uid) FROM '$$PATH$$/3959.dat';

--
-- Data for Name: ir_rule_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_rule_group (id, create_date, create_uid, default_p, global_p, model, name, perm_create, perm_delete, perm_read, perm_write, write_date, write_uid) FROM stdin;
\.
COPY public.ir_rule_group (id, create_date, create_uid, default_p, global_p, model, name, perm_create, perm_delete, perm_read, perm_write, write_date, write_uid) FROM '$$PATH$$/3957.dat';

--
-- Data for Name: ir_rule_group-res_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ir_rule_group-res_group" (id, create_date, create_uid, "group", rule_group, write_date, write_uid) FROM stdin;
\.
COPY public."ir_rule_group-res_group" (id, create_date, create_uid, "group", rule_group, write_date, write_uid) FROM '$$PATH$$/4001.dat';

--
-- Data for Name: ir_sequence; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_sequence (id, active, code, create_date, create_uid, last_timestamp, name, number_increment, number_next_internal, padding, prefix, suffix, timestamp_offset, timestamp_rounding, type, write_date, write_uid) FROM stdin;
\.
COPY public.ir_sequence (id, active, code, create_date, create_uid, last_timestamp, name, number_increment, number_next_internal, padding, prefix, suffix, timestamp_offset, timestamp_rounding, type, write_date, write_uid) FROM '$$PATH$$/3899.dat';

--
-- Data for Name: ir_sequence_strict; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_sequence_strict (id, active, code, create_date, create_uid, last_timestamp, name, number_increment, number_next_internal, padding, prefix, suffix, timestamp_offset, timestamp_rounding, type, write_date, write_uid) FROM stdin;
\.
COPY public.ir_sequence_strict (id, active, code, create_date, create_uid, last_timestamp, name, number_increment, number_next_internal, padding, prefix, suffix, timestamp_offset, timestamp_rounding, type, write_date, write_uid) FROM '$$PATH$$/3901.dat';

--
-- Data for Name: ir_sequence_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_sequence_type (id, code, create_date, create_uid, name, write_date, write_uid) FROM stdin;
\.
COPY public.ir_sequence_type (id, code, create_date, create_uid, name, write_date, write_uid) FROM '$$PATH$$/3897.dat';

--
-- Data for Name: ir_sequence_type-res_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ir_sequence_type-res_group" (id, create_date, create_uid, "group", sequence_type, write_date, write_uid) FROM stdin;
\.
COPY public."ir_sequence_type-res_group" (id, create_date, create_uid, "group", sequence_type, write_date, write_uid) FROM '$$PATH$$/4003.dat';

--
-- Data for Name: ir_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_session (id, create_date, create_uid, key, write_date, write_uid) FROM stdin;
\.
COPY public.ir_session (id, create_date, create_uid, key, write_date, write_uid) FROM '$$PATH$$/3969.dat';

--
-- Data for Name: ir_session_wizard; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_session_wizard (id, create_date, create_uid, data, write_date, write_uid) FROM stdin;
\.
COPY public.ir_session_wizard (id, create_date, create_uid, data, write_date, write_uid) FROM '$$PATH$$/3971.dat';

--
-- Data for Name: ir_translation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_translation (id, lang, src, name, res_id, value, type, module, fuzzy, create_date, create_uid, overriding_module, write_date, write_uid) FROM stdin;
\.
COPY public.ir_translation (id, lang, src, name, res_id, value, type, module, fuzzy, create_date, create_uid, overriding_module, write_date, write_uid) FROM '$$PATH$$/3881.dat';

--
-- Data for Name: ir_trigger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_trigger (id, action, active, condition, create_date, create_uid, limit_number, minimum_time_delay, model, name, on_create, on_delete, on_time, on_write, write_date, write_uid) FROM stdin;
\.
COPY public.ir_trigger (id, action, active, condition, create_date, create_uid, limit_number, minimum_time_delay, model, name, on_create, on_delete, on_time, on_write, write_date, write_uid) FROM '$$PATH$$/3965.dat';

--
-- Data for Name: ir_trigger__history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_trigger__history (id, __id) FROM stdin;
\.
COPY public.ir_trigger__history (id, __id) FROM '$$PATH$$/3963.dat';

--
-- Data for Name: ir_trigger_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_trigger_log (id, create_date, create_uid, record_id, trigger, write_date, write_uid) FROM stdin;
\.
COPY public.ir_trigger_log (id, create_date, create_uid, record_id, trigger, write_date, write_uid) FROM '$$PATH$$/3967.dat';

--
-- Data for Name: ir_ui_icon; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_ui_icon (id, create_date, create_uid, module, name, path, sequence, write_date, write_uid) FROM stdin;
\.
COPY public.ir_ui_icon (id, create_date, create_uid, module, name, path, sequence, write_date, write_uid) FROM '$$PATH$$/3911.dat';

--
-- Data for Name: ir_ui_menu; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_ui_menu (id, parent, name, icon, active, create_date, create_uid, sequence, write_date, write_uid) FROM stdin;
\.
COPY public.ir_ui_menu (id, parent, name, icon, active, create_date, create_uid, sequence, write_date, write_uid) FROM '$$PATH$$/3879.dat';

--
-- Data for Name: ir_ui_menu-res_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ir_ui_menu-res_group" (id, create_date, create_uid, "group", menu, write_date, write_uid) FROM stdin;
\.
COPY public."ir_ui_menu-res_group" (id, create_date, create_uid, "group", menu, write_date, write_uid) FROM '$$PATH$$/3995.dat';

--
-- Data for Name: ir_ui_menu_favorite; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_ui_menu_favorite (id, create_date, create_uid, menu, sequence, "user", write_date, write_uid) FROM stdin;
\.
COPY public.ir_ui_menu_favorite (id, create_date, create_uid, menu, sequence, "user", write_date, write_uid) FROM '$$PATH$$/3903.dat';

--
-- Data for Name: ir_ui_view; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_ui_view (id, model, type, data, field_childs, priority, create_date, create_uid, domain, inherit, module, name, write_date, write_uid) FROM stdin;
\.
COPY public.ir_ui_view (id, model, type, data, field_childs, priority, create_date, create_uid, domain, inherit, module, name, write_date, write_uid) FROM '$$PATH$$/3877.dat';

--
-- Data for Name: ir_ui_view_search; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_ui_view_search (id, create_date, create_uid, domain, model, name, "user", write_date, write_uid) FROM stdin;
\.
COPY public.ir_ui_view_search (id, create_date, create_uid, domain, model, name, "user", write_date, write_uid) FROM '$$PATH$$/3909.dat';

--
-- Data for Name: ir_ui_view_tree_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_ui_view_tree_state (id, child_name, create_date, create_uid, domain, model, nodes, selected_nodes, "user", write_date, write_uid) FROM stdin;
\.
COPY public.ir_ui_view_tree_state (id, child_name, create_date, create_uid, domain, model, nodes, selected_nodes, "user", write_date, write_uid) FROM '$$PATH$$/3907.dat';

--
-- Data for Name: ir_ui_view_tree_width; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir_ui_view_tree_width (id, create_date, create_uid, field, model, "user", width, write_date, write_uid) FROM stdin;
\.
COPY public.ir_ui_view_tree_width (id, create_date, create_uid, field, model, "user", width, write_date, write_uid) FROM '$$PATH$$/3905.dat';

--
-- Data for Name: res_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.res_group (id, name, active, create_date, create_uid, write_date, write_uid) FROM stdin;
\.
COPY public.res_group (id, name, active, create_date, create_uid, write_date, write_uid) FROM '$$PATH$$/3887.dat';

--
-- Data for Name: res_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.res_user (id, name, active, login, password, create_date, create_uid, email, language, menu, password_hash, password_reset, password_reset_expire, signature, write_date, write_uid) FROM stdin;
\.
COPY public.res_user (id, name, active, login, password, create_date, create_uid, email, language, menu, password_hash, password_reset, password_reset_expire, signature, write_date, write_uid) FROM '$$PATH$$/3885.dat';

--
-- Data for Name: res_user-ir_action; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."res_user-ir_action" (id, action, create_date, create_uid, "user", write_date, write_uid) FROM stdin;
\.
COPY public."res_user-ir_action" (id, action, create_date, create_uid, "user", write_date, write_uid) FROM '$$PATH$$/3989.dat';

--
-- Data for Name: res_user-res_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."res_user-res_group" (id, "user", "group", create_date, create_uid, write_date, write_uid) FROM stdin;
\.
COPY public."res_user-res_group" (id, "user", "group", create_date, create_uid, write_date, write_uid) FROM '$$PATH$$/3889.dat';

--
-- Data for Name: res_user_application; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.res_user_application (id, application, create_date, create_uid, key, state, "user", write_date, write_uid) FROM stdin;
\.
COPY public.res_user_application (id, application, create_date, create_uid, key, state, "user", write_date, write_uid) FROM '$$PATH$$/3993.dat';

--
-- Data for Name: res_user_login_attempt; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.res_user_login_attempt (id, create_date, create_uid, ip_address, ip_network, login, write_date, write_uid) FROM stdin;
\.
COPY public.res_user_login_attempt (id, create_date, create_uid, ip_address, ip_network, login, write_date, write_uid) FROM '$$PATH$$/3987.dat';

--
-- Data for Name: res_user_warning; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.res_user_warning (id, always, create_date, create_uid, name, "user", write_date, write_uid) FROM stdin;
\.
COPY public.res_user_warning (id, always, create_date, create_uid, name, "user", write_date, write_uid) FROM '$$PATH$$/3991.dat';

--
-- Name: ir_action-res_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."ir_action-res_group_id_seq"', 4, true);


--
-- Name: ir_action_act_window_domain_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_action_act_window_domain_id_seq', 4, true);


--
-- Name: ir_action_act_window_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_action_act_window_id_seq', 54, true);


--
-- Name: ir_action_act_window_view_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_action_act_window_view_id_seq', 72, true);


--
-- Name: ir_action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_action_id_seq', 56, true);


--
-- Name: ir_action_keyword_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_action_keyword_id_seq', 53, true);


--
-- Name: ir_action_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_action_report_id_seq', 56, true);


--
-- Name: ir_action_url_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_action_url_id_seq', 1, false);


--
-- Name: ir_action_wizard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_action_wizard_id_seq', 55, true);


--
-- Name: ir_attachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_attachment_id_seq', 1, false);


--
-- Name: ir_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_cache_id_seq', 11, true);


--
-- Name: ir_calendar_day_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_calendar_day_id_seq', 7, true);


--
-- Name: ir_calendar_month_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_calendar_month_id_seq', 12, true);


--
-- Name: ir_configuration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_configuration_id_seq', 1, true);


--
-- Name: ir_cron_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_cron_id_seq', 2, true);


--
-- Name: ir_email_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_email_address_id_seq', 1, false);


--
-- Name: ir_email_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_email_id_seq', 1, false);


--
-- Name: ir_email_template-ir_action_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."ir_email_template-ir_action_report_id_seq"', 1, false);


--
-- Name: ir_email_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_email_template_id_seq', 1, false);


--
-- Name: ir_export-res_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."ir_export-res_group_id_seq"', 1, false);


--
-- Name: ir_export-write-res_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."ir_export-write-res_group_id_seq"', 1, false);


--
-- Name: ir_export_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_export_id_seq', 1, false);


--
-- Name: ir_export_line_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_export_line_id_seq', 1, false);


--
-- Name: ir_lang_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_lang_id_seq', 23, true);


--
-- Name: ir_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_message_id_seq', 103, true);


--
-- Name: ir_model_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_model_access_id_seq', 68, true);


--
-- Name: ir_model_button-button_reset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."ir_model_button-button_reset_id_seq"', 1, false);


--
-- Name: ir_model_button-res_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."ir_model_button-res_group_id_seq"', 9, true);


--
-- Name: ir_model_button_click_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_model_button_click_id_seq', 1, false);


--
-- Name: ir_model_button_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_model_button_id_seq', 14, true);


--
-- Name: ir_model_button_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_model_button_rule_id_seq', 1, false);


--
-- Name: ir_model_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_model_data_id_seq', 665, true);


--
-- Name: ir_model_field_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_model_field_access_id_seq', 1, false);


--
-- Name: ir_model_field_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_model_field_id_seq', 866, true);


--
-- Name: ir_model_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_model_id_seq', 85, true);


--
-- Name: ir_module_config_wizard_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_module_config_wizard_item_id_seq', 3, true);


--
-- Name: ir_module_dependency_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_module_dependency_id_seq', 644, true);


--
-- Name: ir_module_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_module_id_seq', 155, true);


--
-- Name: ir_note_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_note_id_seq', 1, false);


--
-- Name: ir_note_read_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_note_read_id_seq', 1, false);


--
-- Name: ir_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_queue_id_seq', 1, false);


--
-- Name: ir_rule_group-res_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."ir_rule_group-res_group_id_seq"', 4, true);


--
-- Name: ir_rule_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_rule_group_id_seq', 24, true);


--
-- Name: ir_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_rule_id_seq', 34, true);


--
-- Name: ir_sequence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_sequence_id_seq', 1, false);


--
-- Name: ir_sequence_strict_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_sequence_strict_id_seq', 1, false);


--
-- Name: ir_sequence_type-res_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."ir_sequence_type-res_group_id_seq"', 1, false);


--
-- Name: ir_sequence_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_sequence_type_id_seq', 1, false);


--
-- Name: ir_session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_session_id_seq', 1, true);


--
-- Name: ir_session_wizard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_session_wizard_id_seq', 2, true);


--
-- Name: ir_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_translation_id_seq', 933, true);


--
-- Name: ir_trigger__history___id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_trigger__history___id_seq', 1, false);


--
-- Name: ir_trigger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_trigger_id_seq', 1, false);


--
-- Name: ir_trigger_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_trigger_log_id_seq', 1, false);


--
-- Name: ir_ui_icon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_ui_icon_id_seq', 8, true);


--
-- Name: ir_ui_menu-res_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."ir_ui_menu-res_group_id_seq"', 40, true);


--
-- Name: ir_ui_menu_favorite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_ui_menu_favorite_id_seq', 1, false);


--
-- Name: ir_ui_menu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_ui_menu_id_seq', 49, true);


--
-- Name: ir_ui_view_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_ui_view_id_seq', 113, true);


--
-- Name: ir_ui_view_search_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_ui_view_search_id_seq', 1, false);


--
-- Name: ir_ui_view_tree_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_ui_view_tree_state_id_seq', 1, false);


--
-- Name: ir_ui_view_tree_width_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir_ui_view_tree_width_id_seq', 1, false);


--
-- Name: res_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.res_group_id_seq', 1, true);


--
-- Name: res_user-ir_action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."res_user-ir_action_id_seq"', 1, false);


--
-- Name: res_user-res_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."res_user-res_group_id_seq"', 1, true);


--
-- Name: res_user_application_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.res_user_application_id_seq', 1, false);


--
-- Name: res_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.res_user_id_seq', 1, true);


--
-- Name: res_user_login_attempt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.res_user_login_attempt_id_seq', 1, false);


--
-- Name: res_user_warning_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.res_user_warning_id_seq', 1, false);


--
-- Name: ir_action-res_group ir_action-res_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_action-res_group"
    ADD CONSTRAINT "ir_action-res_group_pkey" PRIMARY KEY (id);


--
-- Name: ir_action_act_window_domain ir_action_act_window_domain_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action_act_window_domain
    ADD CONSTRAINT ir_action_act_window_domain_pkey PRIMARY KEY (id);


--
-- Name: ir_action_act_window ir_action_act_window_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action_act_window
    ADD CONSTRAINT ir_action_act_window_pkey PRIMARY KEY (id);


--
-- Name: ir_action_act_window_view ir_action_act_window_view_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action_act_window_view
    ADD CONSTRAINT ir_action_act_window_view_pkey PRIMARY KEY (id);


--
-- Name: ir_action_keyword ir_action_keyword_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action_keyword
    ADD CONSTRAINT ir_action_keyword_pkey PRIMARY KEY (id);


--
-- Name: ir_action ir_action_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action
    ADD CONSTRAINT ir_action_pkey PRIMARY KEY (id);


--
-- Name: ir_action_report ir_action_report_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action_report
    ADD CONSTRAINT ir_action_report_pkey PRIMARY KEY (id);


--
-- Name: ir_action_url ir_action_url_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action_url
    ADD CONSTRAINT ir_action_url_pkey PRIMARY KEY (id);


--
-- Name: ir_action_wizard ir_action_wizard_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action_wizard
    ADD CONSTRAINT ir_action_wizard_pkey PRIMARY KEY (id);


--
-- Name: ir_attachment ir_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_attachment
    ADD CONSTRAINT ir_attachment_pkey PRIMARY KEY (id);


--
-- Name: ir_calendar_day ir_calendar_day_index_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_calendar_day
    ADD CONSTRAINT ir_calendar_day_index_unique UNIQUE (index);


--
-- Name: ir_calendar_day ir_calendar_day_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_calendar_day
    ADD CONSTRAINT ir_calendar_day_pkey PRIMARY KEY (id);


--
-- Name: ir_calendar_month ir_calendar_month_index_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_calendar_month
    ADD CONSTRAINT ir_calendar_month_index_unique UNIQUE (index);


--
-- Name: ir_calendar_month ir_calendar_month_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_calendar_month
    ADD CONSTRAINT ir_calendar_month_pkey PRIMARY KEY (id);


--
-- Name: ir_configuration ir_configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_configuration
    ADD CONSTRAINT ir_configuration_pkey PRIMARY KEY (id);


--
-- Name: ir_cron ir_cron_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_cron
    ADD CONSTRAINT ir_cron_pkey PRIMARY KEY (id);


--
-- Name: ir_email_address ir_email_address_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_email_address
    ADD CONSTRAINT ir_email_address_pkey PRIMARY KEY (id);


--
-- Name: ir_email ir_email_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_email
    ADD CONSTRAINT ir_email_pkey PRIMARY KEY (id);


--
-- Name: ir_email_template-ir_action_report ir_email_template-ir_action_report_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_email_template-ir_action_report"
    ADD CONSTRAINT "ir_email_template-ir_action_report_pkey" PRIMARY KEY (id);


--
-- Name: ir_email_template ir_email_template_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_email_template
    ADD CONSTRAINT ir_email_template_pkey PRIMARY KEY (id);


--
-- Name: ir_export-res_group ir_export-res_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_export-res_group"
    ADD CONSTRAINT "ir_export-res_group_pkey" PRIMARY KEY (id);


--
-- Name: ir_export-write-res_group ir_export-write-res_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_export-write-res_group"
    ADD CONSTRAINT "ir_export-write-res_group_pkey" PRIMARY KEY (id);


--
-- Name: ir_export_line ir_export_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_export_line
    ADD CONSTRAINT ir_export_line_pkey PRIMARY KEY (id);


--
-- Name: ir_export ir_export_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_export
    ADD CONSTRAINT ir_export_pkey PRIMARY KEY (id);


--
-- Name: ir_lang ir_lang_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_lang
    ADD CONSTRAINT ir_lang_pkey PRIMARY KEY (id);


--
-- Name: ir_message ir_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_message
    ADD CONSTRAINT ir_message_pkey PRIMARY KEY (id);


--
-- Name: ir_model_access ir_model_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_access
    ADD CONSTRAINT ir_model_access_pkey PRIMARY KEY (id);


--
-- Name: ir_model_button-button_reset ir_model_button-button_reset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_model_button-button_reset"
    ADD CONSTRAINT "ir_model_button-button_reset_pkey" PRIMARY KEY (id);


--
-- Name: ir_model_button-res_group ir_model_button-res_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_model_button-res_group"
    ADD CONSTRAINT "ir_model_button-res_group_pkey" PRIMARY KEY (id);


--
-- Name: ir_model_button_click ir_model_button_click_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_button_click
    ADD CONSTRAINT ir_model_button_click_pkey PRIMARY KEY (id);


--
-- Name: ir_model_button ir_model_button_name_model_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_button
    ADD CONSTRAINT ir_model_button_name_model_uniq UNIQUE (name, model);


--
-- Name: ir_model_button ir_model_button_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_button
    ADD CONSTRAINT ir_model_button_pkey PRIMARY KEY (id);


--
-- Name: ir_model_button_rule ir_model_button_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_button_rule
    ADD CONSTRAINT ir_model_button_rule_pkey PRIMARY KEY (id);


--
-- Name: ir_model_data ir_model_data_fs_id_module_model_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_data
    ADD CONSTRAINT ir_model_data_fs_id_module_model_uniq UNIQUE (fs_id, module, model);


--
-- Name: ir_model_data ir_model_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_data
    ADD CONSTRAINT ir_model_data_pkey PRIMARY KEY (id);


--
-- Name: ir_model_field_access ir_model_field_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_field_access
    ADD CONSTRAINT ir_model_field_access_pkey PRIMARY KEY (id);


--
-- Name: ir_model_field ir_model_field_name_model_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_field
    ADD CONSTRAINT ir_model_field_name_model_uniq UNIQUE (name, model);


--
-- Name: ir_model_field ir_model_field_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_field
    ADD CONSTRAINT ir_model_field_pkey PRIMARY KEY (id);


--
-- Name: ir_model ir_model_model_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model
    ADD CONSTRAINT ir_model_model_uniq UNIQUE (model);


--
-- Name: ir_model ir_model_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model
    ADD CONSTRAINT ir_model_pkey PRIMARY KEY (id);


--
-- Name: ir_module_config_wizard_item ir_module_config_wizard_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_module_config_wizard_item
    ADD CONSTRAINT ir_module_config_wizard_item_pkey PRIMARY KEY (id);


--
-- Name: ir_module_dependency ir_module_dependency_name_module_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_module_dependency
    ADD CONSTRAINT ir_module_dependency_name_module_uniq UNIQUE (name, module);


--
-- Name: ir_module_dependency ir_module_dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_module_dependency
    ADD CONSTRAINT ir_module_dependency_pkey PRIMARY KEY (id);


--
-- Name: ir_module ir_module_name_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_module
    ADD CONSTRAINT ir_module_name_uniq UNIQUE (name);


--
-- Name: ir_module ir_module_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_module
    ADD CONSTRAINT ir_module_pkey PRIMARY KEY (id);


--
-- Name: ir_note ir_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_note
    ADD CONSTRAINT ir_note_pkey PRIMARY KEY (id);


--
-- Name: ir_note_read ir_note_read_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_note_read
    ADD CONSTRAINT ir_note_read_pkey PRIMARY KEY (id);


--
-- Name: ir_queue ir_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_queue
    ADD CONSTRAINT ir_queue_pkey PRIMARY KEY (id);


--
-- Name: ir_rule_group-res_group ir_rule_group-res_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_rule_group-res_group"
    ADD CONSTRAINT "ir_rule_group-res_group_pkey" PRIMARY KEY (id);


--
-- Name: ir_rule_group ir_rule_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_rule_group
    ADD CONSTRAINT ir_rule_group_pkey PRIMARY KEY (id);


--
-- Name: ir_rule ir_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_rule
    ADD CONSTRAINT ir_rule_pkey PRIMARY KEY (id);


--
-- Name: ir_sequence ir_sequence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_sequence
    ADD CONSTRAINT ir_sequence_pkey PRIMARY KEY (id);


--
-- Name: ir_sequence_strict ir_sequence_strict_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_sequence_strict
    ADD CONSTRAINT ir_sequence_strict_pkey PRIMARY KEY (id);


--
-- Name: ir_sequence_type-res_group ir_sequence_type-res_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_sequence_type-res_group"
    ADD CONSTRAINT "ir_sequence_type-res_group_pkey" PRIMARY KEY (id);


--
-- Name: ir_sequence_type ir_sequence_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_sequence_type
    ADD CONSTRAINT ir_sequence_type_pkey PRIMARY KEY (id);


--
-- Name: ir_session ir_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_session
    ADD CONSTRAINT ir_session_pkey PRIMARY KEY (id);


--
-- Name: ir_session_wizard ir_session_wizard_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_session_wizard
    ADD CONSTRAINT ir_session_wizard_pkey PRIMARY KEY (id);


--
-- Name: ir_translation ir_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_translation
    ADD CONSTRAINT ir_translation_pkey PRIMARY KEY (id);


--
-- Name: ir_trigger__history ir_trigger__history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_trigger__history
    ADD CONSTRAINT ir_trigger__history_pkey PRIMARY KEY (__id);


--
-- Name: ir_trigger_log ir_trigger_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_trigger_log
    ADD CONSTRAINT ir_trigger_log_pkey PRIMARY KEY (id);


--
-- Name: ir_trigger ir_trigger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_trigger
    ADD CONSTRAINT ir_trigger_pkey PRIMARY KEY (id);


--
-- Name: ir_ui_icon ir_ui_icon_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_ui_icon
    ADD CONSTRAINT ir_ui_icon_pkey PRIMARY KEY (id);


--
-- Name: ir_ui_menu-res_group ir_ui_menu-res_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_ui_menu-res_group"
    ADD CONSTRAINT "ir_ui_menu-res_group_pkey" PRIMARY KEY (id);


--
-- Name: ir_ui_menu_favorite ir_ui_menu_favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_ui_menu_favorite
    ADD CONSTRAINT ir_ui_menu_favorite_pkey PRIMARY KEY (id);


--
-- Name: ir_ui_menu ir_ui_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_ui_menu
    ADD CONSTRAINT ir_ui_menu_pkey PRIMARY KEY (id);


--
-- Name: ir_ui_view ir_ui_view_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_ui_view
    ADD CONSTRAINT ir_ui_view_pkey PRIMARY KEY (id);


--
-- Name: ir_ui_view_search ir_ui_view_search_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_ui_view_search
    ADD CONSTRAINT ir_ui_view_search_pkey PRIMARY KEY (id);


--
-- Name: ir_ui_view_tree_state ir_ui_view_tree_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_ui_view_tree_state
    ADD CONSTRAINT ir_ui_view_tree_state_pkey PRIMARY KEY (id);


--
-- Name: ir_ui_view_tree_width ir_ui_view_tree_width_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_ui_view_tree_width
    ADD CONSTRAINT ir_ui_view_tree_width_pkey PRIMARY KEY (id);


--
-- Name: res_group res_group_name_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.res_group
    ADD CONSTRAINT res_group_name_uniq UNIQUE (name);


--
-- Name: res_group res_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.res_group
    ADD CONSTRAINT res_group_pkey PRIMARY KEY (id);


--
-- Name: res_user-ir_action res_user-ir_action_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."res_user-ir_action"
    ADD CONSTRAINT "res_user-ir_action_pkey" PRIMARY KEY (id);


--
-- Name: res_user-res_group res_user-res_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."res_user-res_group"
    ADD CONSTRAINT "res_user-res_group_pkey" PRIMARY KEY (id);


--
-- Name: res_user_application res_user_application_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.res_user_application
    ADD CONSTRAINT res_user_application_pkey PRIMARY KEY (id);


--
-- Name: res_user_login_attempt res_user_login_attempt_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.res_user_login_attempt
    ADD CONSTRAINT res_user_login_attempt_pkey PRIMARY KEY (id);


--
-- Name: res_user res_user_login_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.res_user
    ADD CONSTRAINT res_user_login_key UNIQUE (login);


--
-- Name: res_user res_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.res_user
    ADD CONSTRAINT res_user_pkey PRIMARY KEY (id);


--
-- Name: res_user_warning res_user_warning_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.res_user_warning
    ADD CONSTRAINT res_user_warning_pkey PRIMARY KEY (id);


--
-- Name: e58f52dd207acfc3836ab6ec0b9aa054e35cbce07f3cfb9bc5a06e2d89daf2f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX e58f52dd207acfc3836ab6ec0b9aa054e35cbce07f3cfb9bc5a06e2d89daf2f ON public.ir_queue USING btree (scheduled_at NULLS FIRST, expected_at NULLS FIRST, dequeued_at, name);


--
-- Name: ir_action-res_group_action_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ir_action-res_group_action_index" ON public."ir_action-res_group" USING btree (action);


--
-- Name: ir_action-res_group_group_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ir_action-res_group_group_index" ON public."ir_action-res_group" USING btree ("group");


--
-- Name: ir_action_act_window_domain_act_window_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_action_act_window_domain_act_window_index ON public.ir_action_act_window_domain USING btree (act_window);


--
-- Name: ir_action_keyword_action_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_action_keyword_action_index ON public.ir_action_keyword USING btree (action);


--
-- Name: ir_action_keyword_keyword_model_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_action_keyword_keyword_model_index ON public.ir_action_keyword USING btree (keyword, model);


--
-- Name: ir_action_report_module_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_action_report_module_index ON public.ir_action_report USING btree (module);


--
-- Name: ir_attachment_resource_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_attachment_resource_index ON public.ir_attachment USING btree (resource);


--
-- Name: ir_cron_next_call_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_cron_next_call_index ON public.ir_cron USING btree (next_call);


--
-- Name: ir_email_address_address_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_email_address_address_index ON public.ir_email_address USING btree (address);


--
-- Name: ir_email_address_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_email_address_email_index ON public.ir_email_address USING btree (email);


--
-- Name: ir_email_resource_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_email_resource_index ON public.ir_email USING btree (resource);


--
-- Name: ir_export-res_group_export_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ir_export-res_group_export_index" ON public."ir_export-res_group" USING btree (export);


--
-- Name: ir_export-write-res_group_export_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ir_export-write-res_group_export_index" ON public."ir_export-write-res_group" USING btree (export);


--
-- Name: ir_export_line_export_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_export_line_export_index ON public.ir_export_line USING btree (export);


--
-- Name: ir_model_button-button_reset_button_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ir_model_button-button_reset_button_index" ON public."ir_model_button-button_reset" USING btree (button);


--
-- Name: ir_model_button-button_reset_button_ruled_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ir_model_button-button_reset_button_ruled_index" ON public."ir_model_button-button_reset" USING btree (button_ruled);


--
-- Name: ir_model_button-res_group_button_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ir_model_button-res_group_button_index" ON public."ir_model_button-res_group" USING btree (button);


--
-- Name: ir_model_button-res_group_group_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ir_model_button-res_group_group_index" ON public."ir_model_button-res_group" USING btree ("group");


--
-- Name: ir_model_button_model_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_model_button_model_index ON public.ir_model_button USING btree (model);


--
-- Name: ir_model_data_db_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_model_data_db_id_index ON public.ir_model_data USING btree (db_id);


--
-- Name: ir_model_data_fs_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_model_data_fs_id_index ON public.ir_model_data USING btree (fs_id);


--
-- Name: ir_model_data_model_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_model_data_model_index ON public.ir_model_data USING btree (model);


--
-- Name: ir_model_data_module_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_model_data_module_index ON public.ir_model_data USING btree (module);


--
-- Name: ir_model_field_model_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_model_field_model_index ON public.ir_model_field USING btree (model);


--
-- Name: ir_module_config_wizard_item_state_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_module_config_wizard_item_state_index ON public.ir_module_config_wizard_item USING btree (state);


--
-- Name: ir_module_dependency_module_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_module_dependency_module_index ON public.ir_module_dependency USING btree (module);


--
-- Name: ir_note_resource_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_note_resource_index ON public.ir_note USING btree (resource);


--
-- Name: ir_rule_group-res_group_group_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ir_rule_group-res_group_group_index" ON public."ir_rule_group-res_group" USING btree ("group");


--
-- Name: ir_rule_group-res_group_rule_group_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ir_rule_group-res_group_rule_group_index" ON public."ir_rule_group-res_group" USING btree (rule_group);


--
-- Name: ir_rule_group_default_p_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_rule_group_default_p_index ON public.ir_rule_group USING btree (default_p);


--
-- Name: ir_rule_group_global_p_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_rule_group_global_p_index ON public.ir_rule_group USING btree (global_p);


--
-- Name: ir_rule_group_model_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_rule_group_model_index ON public.ir_rule_group USING btree (model);


--
-- Name: ir_rule_group_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_rule_group_name_index ON public.ir_rule_group USING btree (name);


--
-- Name: ir_rule_rule_group_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_rule_rule_group_index ON public.ir_rule USING btree (rule_group);


--
-- Name: ir_sequence_type-res_group_group_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ir_sequence_type-res_group_group_index" ON public."ir_sequence_type-res_group" USING btree ("group");


--
-- Name: ir_sequence_type-res_group_sequence_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ir_sequence_type-res_group_sequence_type_index" ON public."ir_sequence_type-res_group" USING btree (sequence_type);


--
-- Name: ir_session_create_uid_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_session_create_uid_index ON public.ir_session USING btree (create_uid);


--
-- Name: ir_session_key_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_session_key_index ON public.ir_session USING btree (key);


--
-- Name: ir_translation_lang_type_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_translation_lang_type_name_index ON public.ir_translation USING btree (lang, type, name);


--
-- Name: ir_translation_res_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_translation_res_id_index ON public.ir_translation USING btree (res_id);


--
-- Name: ir_trigger_log_trigger_record_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_trigger_log_trigger_record_id_index ON public.ir_trigger_log USING btree (trigger, record_id);


--
-- Name: ir_trigger_model_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_trigger_model_index ON public.ir_trigger USING btree (model);


--
-- Name: ir_trigger_on_create_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_trigger_on_create_index ON public.ir_trigger USING btree (on_create);


--
-- Name: ir_trigger_on_delete_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_trigger_on_delete_index ON public.ir_trigger USING btree (on_delete);


--
-- Name: ir_trigger_on_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_trigger_on_time_index ON public.ir_trigger USING btree (on_time);


--
-- Name: ir_trigger_on_write_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_trigger_on_write_index ON public.ir_trigger USING btree (on_write);


--
-- Name: ir_ui_icon_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_ui_icon_name_index ON public.ir_ui_icon USING btree (name);


--
-- Name: ir_ui_menu-res_group_group_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ir_ui_menu-res_group_group_index" ON public."ir_ui_menu-res_group" USING btree ("group");


--
-- Name: ir_ui_menu-res_group_menu_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ir_ui_menu-res_group_menu_index" ON public."ir_ui_menu-res_group" USING btree (menu);


--
-- Name: ir_ui_menu_parent_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_ui_menu_parent_index ON public.ir_ui_menu USING btree (parent);


--
-- Name: ir_ui_view_inherit_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_ui_view_inherit_index ON public.ir_ui_view USING btree (inherit);


--
-- Name: ir_ui_view_model_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_ui_view_model_index ON public.ir_ui_view USING btree (model);


--
-- Name: ir_ui_view_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_ui_view_priority_index ON public.ir_ui_view USING btree (priority);


--
-- Name: ir_ui_view_tree_state_model_domain_user_child_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_ui_view_tree_state_model_domain_user_child_name_index ON public.ir_ui_view_tree_state USING btree (model, domain, "user", child_name);


--
-- Name: ir_ui_view_tree_width_field_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_ui_view_tree_width_field_index ON public.ir_ui_view_tree_width USING btree (field);


--
-- Name: ir_ui_view_tree_width_model_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_ui_view_tree_width_model_index ON public.ir_ui_view_tree_width USING btree (model);


--
-- Name: ir_ui_view_tree_width_user_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_ui_view_tree_width_user_index ON public.ir_ui_view_tree_width USING btree ("user");


--
-- Name: ir_ui_view_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir_ui_view_type_index ON public.ir_ui_view USING btree (type);


--
-- Name: res_group_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX res_group_name_index ON public.res_group USING btree (name);


--
-- Name: res_user-ir_action_action_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "res_user-ir_action_action_index" ON public."res_user-ir_action" USING btree (action);


--
-- Name: res_user-ir_action_user_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "res_user-ir_action_user_index" ON public."res_user-ir_action" USING btree ("user");


--
-- Name: res_user-res_group_group_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "res_user-res_group_group_index" ON public."res_user-res_group" USING btree ("group");


--
-- Name: res_user-res_group_user_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "res_user-res_group_user_index" ON public."res_user-res_group" USING btree ("user");


--
-- Name: res_user_application_key_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX res_user_application_key_index ON public.res_user_application USING btree (key);


--
-- Name: res_user_application_user_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX res_user_application_user_index ON public.res_user_application USING btree ("user");


--
-- Name: res_user_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX res_user_name_index ON public.res_user USING btree (name);


--
-- Name: res_user_warning_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX res_user_warning_name_index ON public.res_user_warning USING btree (name);


--
-- Name: res_user_warning_user_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX res_user_warning_user_index ON public.res_user_warning USING btree ("user");


--
-- Name: ir_action-res_group ir_action-res_group_action_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_action-res_group"
    ADD CONSTRAINT "ir_action-res_group_action_fkey" FOREIGN KEY (action) REFERENCES public.ir_action(id) ON DELETE CASCADE;


--
-- Name: ir_action-res_group ir_action-res_group_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_action-res_group"
    ADD CONSTRAINT "ir_action-res_group_group_fkey" FOREIGN KEY ("group") REFERENCES public.res_group(id) ON DELETE CASCADE;


--
-- Name: ir_action_act_window ir_action_act_window_action_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action_act_window
    ADD CONSTRAINT ir_action_act_window_action_fkey FOREIGN KEY (action) REFERENCES public.ir_action(id) ON DELETE CASCADE;


--
-- Name: ir_action_act_window_domain ir_action_act_window_domain_act_window_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action_act_window_domain
    ADD CONSTRAINT ir_action_act_window_domain_act_window_fkey FOREIGN KEY (act_window) REFERENCES public.ir_action_act_window(id) ON DELETE CASCADE;


--
-- Name: ir_action_act_window_view ir_action_act_window_view_act_window_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action_act_window_view
    ADD CONSTRAINT ir_action_act_window_view_act_window_fkey FOREIGN KEY (act_window) REFERENCES public.ir_action_act_window(id) ON DELETE CASCADE;


--
-- Name: ir_action_act_window_view ir_action_act_window_view_view_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action_act_window_view
    ADD CONSTRAINT ir_action_act_window_view_view_fkey FOREIGN KEY (view) REFERENCES public.ir_ui_view(id) ON DELETE CASCADE;


--
-- Name: ir_action ir_action_icon_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action
    ADD CONSTRAINT ir_action_icon_fkey FOREIGN KEY (icon) REFERENCES public.ir_ui_icon(id) ON DELETE SET NULL;


--
-- Name: ir_action_keyword ir_action_keyword_action_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action_keyword
    ADD CONSTRAINT ir_action_keyword_action_fkey FOREIGN KEY (action) REFERENCES public.ir_action(id) ON DELETE CASCADE;


--
-- Name: ir_action_report ir_action_report_action_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action_report
    ADD CONSTRAINT ir_action_report_action_fkey FOREIGN KEY (action) REFERENCES public.ir_action(id) ON DELETE CASCADE;


--
-- Name: ir_action_url ir_action_url_action_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action_url
    ADD CONSTRAINT ir_action_url_action_fkey FOREIGN KEY (action) REFERENCES public.ir_action(id) ON DELETE CASCADE;


--
-- Name: ir_action_wizard ir_action_wizard_action_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_action_wizard
    ADD CONSTRAINT ir_action_wizard_action_fkey FOREIGN KEY (action) REFERENCES public.ir_action(id) ON DELETE CASCADE;


--
-- Name: ir_cron ir_cron_weekday_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_cron
    ADD CONSTRAINT ir_cron_weekday_fkey FOREIGN KEY (weekday) REFERENCES public.ir_calendar_day(id) ON DELETE SET NULL;


--
-- Name: ir_email_address ir_email_address_email_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_email_address
    ADD CONSTRAINT ir_email_address_email_fkey FOREIGN KEY (email) REFERENCES public.ir_email(id) ON DELETE CASCADE;


--
-- Name: ir_email_template-ir_action_report ir_email_template-ir_action_report_report_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_email_template-ir_action_report"
    ADD CONSTRAINT "ir_email_template-ir_action_report_report_fkey" FOREIGN KEY (report) REFERENCES public.ir_action_report(id) ON DELETE CASCADE;


--
-- Name: ir_email_template-ir_action_report ir_email_template-ir_action_report_template_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_email_template-ir_action_report"
    ADD CONSTRAINT "ir_email_template-ir_action_report_template_fkey" FOREIGN KEY (template) REFERENCES public.ir_email_template(id) ON DELETE CASCADE;


--
-- Name: ir_email_template ir_email_template_model_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_email_template
    ADD CONSTRAINT ir_email_template_model_fkey FOREIGN KEY (model) REFERENCES public.ir_model(id) ON DELETE RESTRICT;


--
-- Name: ir_email_template ir_email_template_recipients_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_email_template
    ADD CONSTRAINT ir_email_template_recipients_fkey FOREIGN KEY (recipients) REFERENCES public.ir_model_field(id) ON DELETE SET NULL;


--
-- Name: ir_email_template ir_email_template_recipients_hidden_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_email_template
    ADD CONSTRAINT ir_email_template_recipients_hidden_fkey FOREIGN KEY (recipients_hidden) REFERENCES public.ir_model_field(id) ON DELETE SET NULL;


--
-- Name: ir_email_template ir_email_template_recipients_secondary_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_email_template
    ADD CONSTRAINT ir_email_template_recipients_secondary_fkey FOREIGN KEY (recipients_secondary) REFERENCES public.ir_model_field(id) ON DELETE SET NULL;


--
-- Name: ir_export-res_group ir_export-res_group_export_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_export-res_group"
    ADD CONSTRAINT "ir_export-res_group_export_fkey" FOREIGN KEY (export) REFERENCES public.ir_export(id) ON DELETE CASCADE;


--
-- Name: ir_export-res_group ir_export-res_group_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_export-res_group"
    ADD CONSTRAINT "ir_export-res_group_group_fkey" FOREIGN KEY ("group") REFERENCES public.res_group(id) ON DELETE CASCADE;


--
-- Name: ir_export-write-res_group ir_export-write-res_group_export_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_export-write-res_group"
    ADD CONSTRAINT "ir_export-write-res_group_export_fkey" FOREIGN KEY (export) REFERENCES public.ir_export(id) ON DELETE CASCADE;


--
-- Name: ir_export-write-res_group ir_export-write-res_group_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_export-write-res_group"
    ADD CONSTRAINT "ir_export-write-res_group_group_fkey" FOREIGN KEY ("group") REFERENCES public.res_group(id) ON DELETE CASCADE;


--
-- Name: ir_export_line ir_export_line_export_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_export_line
    ADD CONSTRAINT ir_export_line_export_fkey FOREIGN KEY (export) REFERENCES public.ir_export(id) ON DELETE CASCADE;


--
-- Name: ir_model_access ir_model_access_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_access
    ADD CONSTRAINT ir_model_access_group_fkey FOREIGN KEY ("group") REFERENCES public.res_group(id) ON DELETE CASCADE;


--
-- Name: ir_model_access ir_model_access_model_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_access
    ADD CONSTRAINT ir_model_access_model_fkey FOREIGN KEY (model) REFERENCES public.ir_model(id) ON DELETE CASCADE;


--
-- Name: ir_model_button-button_reset ir_model_button-button_reset_button_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_model_button-button_reset"
    ADD CONSTRAINT "ir_model_button-button_reset_button_fkey" FOREIGN KEY (button) REFERENCES public.ir_model_button(id) ON DELETE CASCADE;


--
-- Name: ir_model_button-button_reset ir_model_button-button_reset_button_ruled_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_model_button-button_reset"
    ADD CONSTRAINT "ir_model_button-button_reset_button_ruled_fkey" FOREIGN KEY (button_ruled) REFERENCES public.ir_model_button(id) ON DELETE CASCADE;


--
-- Name: ir_model_button-res_group ir_model_button-res_group_button_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_model_button-res_group"
    ADD CONSTRAINT "ir_model_button-res_group_button_fkey" FOREIGN KEY (button) REFERENCES public.ir_model_button(id) ON DELETE CASCADE;


--
-- Name: ir_model_button-res_group ir_model_button-res_group_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_model_button-res_group"
    ADD CONSTRAINT "ir_model_button-res_group_group_fkey" FOREIGN KEY ("group") REFERENCES public.res_group(id) ON DELETE CASCADE;


--
-- Name: ir_model_button_click ir_model_button_click_button_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_button_click
    ADD CONSTRAINT ir_model_button_click_button_fkey FOREIGN KEY (button) REFERENCES public.ir_model_button(id) ON DELETE CASCADE;


--
-- Name: ir_model_button_click ir_model_button_click_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_button_click
    ADD CONSTRAINT ir_model_button_click_user_fkey FOREIGN KEY ("user") REFERENCES public.res_user(id) ON DELETE CASCADE;


--
-- Name: ir_model_button ir_model_button_model_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_button
    ADD CONSTRAINT ir_model_button_model_fkey FOREIGN KEY (model) REFERENCES public.ir_model(id) ON DELETE CASCADE;


--
-- Name: ir_model_button_rule ir_model_button_rule_button_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_button_rule
    ADD CONSTRAINT ir_model_button_rule_button_fkey FOREIGN KEY (button) REFERENCES public.ir_model_button(id) ON DELETE CASCADE;


--
-- Name: ir_model_button_rule ir_model_button_rule_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_button_rule
    ADD CONSTRAINT ir_model_button_rule_group_fkey FOREIGN KEY ("group") REFERENCES public.res_group(id) ON DELETE CASCADE;


--
-- Name: ir_model_field_access ir_model_field_access_field_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_field_access
    ADD CONSTRAINT ir_model_field_access_field_fkey FOREIGN KEY (field) REFERENCES public.ir_model_field(id) ON DELETE CASCADE;


--
-- Name: ir_model_field_access ir_model_field_access_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_field_access
    ADD CONSTRAINT ir_model_field_access_group_fkey FOREIGN KEY ("group") REFERENCES public.res_group(id) ON DELETE CASCADE;


--
-- Name: ir_model_field ir_model_field_model_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_model_field
    ADD CONSTRAINT ir_model_field_model_fkey FOREIGN KEY (model) REFERENCES public.ir_model(id) ON DELETE CASCADE;


--
-- Name: ir_module_config_wizard_item ir_module_config_wizard_item_action_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_module_config_wizard_item
    ADD CONSTRAINT ir_module_config_wizard_item_action_fkey FOREIGN KEY (action) REFERENCES public.ir_action(id) ON DELETE RESTRICT;


--
-- Name: ir_module_dependency ir_module_dependency_module_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_module_dependency
    ADD CONSTRAINT ir_module_dependency_module_fkey FOREIGN KEY (module) REFERENCES public.ir_module(id) ON DELETE CASCADE;


--
-- Name: ir_note_read ir_note_read_note_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_note_read
    ADD CONSTRAINT ir_note_read_note_fkey FOREIGN KEY (note) REFERENCES public.ir_note(id) ON DELETE CASCADE;


--
-- Name: ir_note_read ir_note_read_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_note_read
    ADD CONSTRAINT ir_note_read_user_fkey FOREIGN KEY ("user") REFERENCES public.res_user(id) ON DELETE CASCADE;


--
-- Name: ir_rule_group-res_group ir_rule_group-res_group_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_rule_group-res_group"
    ADD CONSTRAINT "ir_rule_group-res_group_group_fkey" FOREIGN KEY ("group") REFERENCES public.res_group(id) ON DELETE CASCADE;


--
-- Name: ir_rule_group-res_group ir_rule_group-res_group_rule_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_rule_group-res_group"
    ADD CONSTRAINT "ir_rule_group-res_group_rule_group_fkey" FOREIGN KEY (rule_group) REFERENCES public.ir_rule_group(id) ON DELETE CASCADE;


--
-- Name: ir_rule_group ir_rule_group_model_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_rule_group
    ADD CONSTRAINT ir_rule_group_model_fkey FOREIGN KEY (model) REFERENCES public.ir_model(id) ON DELETE CASCADE;


--
-- Name: ir_rule ir_rule_rule_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_rule
    ADD CONSTRAINT ir_rule_rule_group_fkey FOREIGN KEY (rule_group) REFERENCES public.ir_rule_group(id) ON DELETE CASCADE;


--
-- Name: ir_sequence_type-res_group ir_sequence_type-res_group_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_sequence_type-res_group"
    ADD CONSTRAINT "ir_sequence_type-res_group_group_fkey" FOREIGN KEY ("group") REFERENCES public.res_group(id) ON DELETE CASCADE;


--
-- Name: ir_sequence_type-res_group ir_sequence_type-res_group_sequence_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_sequence_type-res_group"
    ADD CONSTRAINT "ir_sequence_type-res_group_sequence_type_fkey" FOREIGN KEY (sequence_type) REFERENCES public.ir_sequence_type(id) ON DELETE CASCADE;


--
-- Name: ir_trigger_log ir_trigger_log_trigger_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_trigger_log
    ADD CONSTRAINT ir_trigger_log_trigger_fkey FOREIGN KEY (trigger) REFERENCES public.ir_trigger(id) ON DELETE CASCADE;


--
-- Name: ir_trigger ir_trigger_model_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_trigger
    ADD CONSTRAINT ir_trigger_model_fkey FOREIGN KEY (model) REFERENCES public.ir_model(id) ON DELETE RESTRICT;


--
-- Name: ir_ui_menu-res_group ir_ui_menu-res_group_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_ui_menu-res_group"
    ADD CONSTRAINT "ir_ui_menu-res_group_group_fkey" FOREIGN KEY ("group") REFERENCES public.res_group(id) ON DELETE CASCADE;


--
-- Name: ir_ui_menu-res_group ir_ui_menu-res_group_menu_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ir_ui_menu-res_group"
    ADD CONSTRAINT "ir_ui_menu-res_group_menu_fkey" FOREIGN KEY (menu) REFERENCES public.ir_ui_menu(id) ON DELETE CASCADE;


--
-- Name: ir_ui_menu_favorite ir_ui_menu_favorite_menu_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_ui_menu_favorite
    ADD CONSTRAINT ir_ui_menu_favorite_menu_fkey FOREIGN KEY (menu) REFERENCES public.ir_ui_menu(id) ON DELETE CASCADE;


--
-- Name: ir_ui_menu_favorite ir_ui_menu_favorite_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_ui_menu_favorite
    ADD CONSTRAINT ir_ui_menu_favorite_user_fkey FOREIGN KEY ("user") REFERENCES public.res_user(id) ON DELETE CASCADE;


--
-- Name: ir_ui_menu ir_ui_menu_parent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_ui_menu
    ADD CONSTRAINT ir_ui_menu_parent_fkey FOREIGN KEY (parent) REFERENCES public.ir_ui_menu(id) ON DELETE CASCADE;


--
-- Name: ir_ui_view ir_ui_view_inherit_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_ui_view
    ADD CONSTRAINT ir_ui_view_inherit_fkey FOREIGN KEY (inherit) REFERENCES public.ir_ui_view(id) ON DELETE CASCADE;


--
-- Name: ir_ui_view_search ir_ui_view_search_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_ui_view_search
    ADD CONSTRAINT ir_ui_view_search_user_fkey FOREIGN KEY ("user") REFERENCES public.res_user(id) ON DELETE CASCADE;


--
-- Name: ir_ui_view_tree_state ir_ui_view_tree_state_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_ui_view_tree_state
    ADD CONSTRAINT ir_ui_view_tree_state_user_fkey FOREIGN KEY ("user") REFERENCES public.res_user(id) ON DELETE CASCADE;


--
-- Name: ir_ui_view_tree_width ir_ui_view_tree_width_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir_ui_view_tree_width
    ADD CONSTRAINT ir_ui_view_tree_width_user_fkey FOREIGN KEY ("user") REFERENCES public.res_user(id) ON DELETE CASCADE;


--
-- Name: res_user-ir_action res_user-ir_action_action_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."res_user-ir_action"
    ADD CONSTRAINT "res_user-ir_action_action_fkey" FOREIGN KEY (action) REFERENCES public.ir_action(id) ON DELETE CASCADE;


--
-- Name: res_user-ir_action res_user-ir_action_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."res_user-ir_action"
    ADD CONSTRAINT "res_user-ir_action_user_fkey" FOREIGN KEY ("user") REFERENCES public.res_user(id) ON DELETE CASCADE;


--
-- Name: res_user-res_group res_user-res_group_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."res_user-res_group"
    ADD CONSTRAINT "res_user-res_group_group_fkey" FOREIGN KEY ("group") REFERENCES public.res_group(id) ON DELETE CASCADE;


--
-- Name: res_user-res_group res_user-res_group_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."res_user-res_group"
    ADD CONSTRAINT "res_user-res_group_user_fkey" FOREIGN KEY ("user") REFERENCES public.res_user(id) ON DELETE CASCADE;


--
-- Name: res_user_application res_user_application_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.res_user_application
    ADD CONSTRAINT res_user_application_user_fkey FOREIGN KEY ("user") REFERENCES public.res_user(id) ON DELETE SET NULL;


--
-- Name: res_user res_user_language_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.res_user
    ADD CONSTRAINT res_user_language_fkey FOREIGN KEY (language) REFERENCES public.ir_lang(id) ON DELETE SET NULL;


--
-- Name: res_user res_user_menu_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.res_user
    ADD CONSTRAINT res_user_menu_fkey FOREIGN KEY (menu) REFERENCES public.ir_action(id) ON DELETE RESTRICT;


--
-- Name: res_user_warning res_user_warning_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.res_user_warning
    ADD CONSTRAINT res_user_warning_user_fkey FOREIGN KEY ("user") REFERENCES public.res_user(id) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

